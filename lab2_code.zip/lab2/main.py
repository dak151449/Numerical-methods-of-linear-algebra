import random
import numpy as np

def mul_matrix(A, B):
    n = len(A)
    m = len(B[0])
    C = [[0] * m for _ in range(n)]
    for i in range(n):
        for j in range(m):
            for k in range(len(B)):
                C[i][j] += A[i][k] * B[k][j]
    return C


def gener_matrix(maxx, minn, n, m):
    matrix = n * [0]
    for i in range(n):
        l = []
        for j in range(m):
            l.append(random.uniform(float(minn), float(maxx)))
        matrix[i] = l
    return matrix

def add_diag(matrix, n):
    for i in range(len(matrix)):
        matrix[i][i] += n
    return matrix


def gauss_method(matrix, equal):
    n = len(matrix)
    for i in range(n):
        maxElem = abs(matrix[i][i])
        maxRow = i
        for k in range(i + 1, n):
            if abs(matrix[k][i]) > maxElem:
                maxElem = abs(matrix[k][i])
                maxRow = k

        matrix[i], matrix[maxRow] = matrix[maxRow], matrix[i]
        equal[i], equal[maxRow] = equal[maxRow], equal[i]

        for k in range(i + 1, n):
            c = -matrix[k][i] / matrix[i][i]
            for j in range(i, n):
                if i == j:
                    matrix[k][j] = 0
                else:
                    matrix[k][j] += c * matrix[i][j]
            equal[k][0] += c * equal[i][0]

    return matrix, equal

def evklid_norm(list_X, list_Y):
    norm = 0
    for i in range(len(list_X)):
        norm += (list_X[i] - list_Y[i]) ** 2
    return norm ** 0.5

def main():
    n = int(input())
    m = n

    

    matrix = gener_matrix(-100, 100, n, m)
    list_X = []
    for i in range(n):
        list_X.append([random.uniform(-100,  100)])
    #list_X = [[1/3], [1/3]]
    #print(matrix)
    #matrix = [list(map(int, input().split())) for _ in range(n)]

    equal = mul_matrix(matrix, list_X)

    #print(matrix, equal)
    matrix, equal = gauss_method(matrix, equal)

    list_X_new = [0] * n
    

    for i in range(n - 1, -1, -1):
        sum_ = equal[i][0]
        for j in range(i + 1, n):
            sum_ -= matrix[i][j] * list_X_new[j]
        list_X_new[i] = sum_ / matrix[i][i]

    #print(list_X_new)
    l = []
    for i in range(n):
        l.append(list_X[i][0])
    #print(evklid_norm(l, list_X_new))

    l = []
    for i in range(n):
        l.append(equal[i][0])
    out = np.linalg.solve(matrix, l)
    #print(out)

    print(evklid_norm(out, list_X_new))
main()